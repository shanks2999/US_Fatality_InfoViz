# Directions
Since AR.js is a marker based AR library, open the attached HIRO marker, launch the deployed [demo app](https://iss-ar.herokuapp.com/) and point it at the marker.
